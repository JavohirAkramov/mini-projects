import React from "react";
import { BrowserRouter } from "react-router-dom";
import Auth from "./components/Auth/Auth";

export default function App() {
  return (
    <BrowserRouter>
      <Auth />
    </BrowserRouter>
  );
}
