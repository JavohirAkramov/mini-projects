import React from "react";

function Admin() {
  return (
    <div>
      <h1>Admin page</h1>
    </div>
  );
}

export default Admin;
