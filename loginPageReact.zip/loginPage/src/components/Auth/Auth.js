import React, { useState, useEffect } from "react";
import { Routes, Route } from "react-router-dom";
import SignUp from "./SignUp";
import SignIn from "./SignIn";
import Home from "../Home/Home";
import Admin from "../Admin/Admin";
import ProtectedRoute from "./ProtectedRoute";
import styled from "styled-components";

const AuthContainer = styled.div`
  margin: 32px auto;
  padding: 32px;
  width: 40%;
  background-color: #eee;
  border-radius: 32px;
  font-family: serif;
  @media only screen and (max-width: 800px) {
    width: 80%;
  }
  @media only screen and (max-width: 320px) {
    width: 100%;
  }
`;

function Auth() {
  const [isAuth, setAuth] = useState(false);
  const [isAdmin, setAdmin] = useState(false);
  useEffect(() => {
    setAuth(localStorage.getItem("isAuth"));
    setAdmin(localStorage.getItem("isAdmin"));

    localStorage.getItem("isAuth") ? setAuth(true) : setAuth(false);
  }, []);

  return (
    <AuthContainer>
      <Routes>
        <Route path="/signin" element={<SignIn />} />
        <Route path="/signup" element={<SignUp />} />
        <Route
          path="/home"
          element={
            <ProtectedRoute>
              <Home />
            </ProtectedRoute>
          }
        />
        <Route
          path="/admin"
          element={
            <ProtectedRoute>
              <Admin />
            </ProtectedRoute>
          }
        />

        {!isAuth ? (
          <Route path="/" element={<SignUp />} />
        ) : isAdmin ? (
          <Route path="/" element={<Admin />} />
        ) : (
          <Route path="/" element={<Home />} />
        )}
      </Routes>
    </AuthContainer>
  );
}

export default Auth;
